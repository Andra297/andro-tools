![#f03c15](https://placehold.it/15/f03c15/000000?text=+)![#f03c15](https://placehold.it/15/f03c15/000000?text=+)![#f03c15](https://placehold.it/15/f03c15/000000?text=+) __IMPORTANT: THIS PROJECT IS NO LONGER MAINTAINED__  
![#f03c15](https://placehold.it/15/f03c15/000000?text=+)![#f03c15](https://placehold.it/15/f03c15/000000?text=+)![#f03c15](https://placehold.it/15/f03c15/000000?text=+) __IF YOU WANT UPDATES, PLEASE FORK YOUR OWN VERSION__

bootimg-tools
=============

Android boot.img creation and extraction tools (also MinGW compatible)

Based on the original Android bootimg tools from:
  https://android.googlesource.com/platform/system/core

__NOTE: This project is no longer maintained__
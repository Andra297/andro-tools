# bn_vmlinux_2_elf
ripping out a vmlinux loaded and converting it back to an elf file
